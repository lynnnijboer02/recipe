module.exports = {
    css: ['~assets/scss/main']
}