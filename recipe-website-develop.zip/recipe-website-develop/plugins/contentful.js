/**
 * Contentful API plugin
 */

// const contentful = require('contentful');

// export default ({ $config }, inject) => {
//     inject(
//         'contentful',
//         contentful.createClient({
//             space: $config.CTF_SPACE_ID,
//             host: $config.CTF_HOST,
//             accessToken: $config.CTF_CDA_ACCESS_TOKEN,
//         }),
//     );
// };